var s = document.createElement('script');
s.src = chrome.extension.getURL('autobuyer.js'); 
(document.head||document.documentElement).appendChild(s); 
s.onload = function () { 
    s.parentNode.removeChild(s);
}; 

var fas = document.createElement('div');
fas.id = "FUTCKEXTENSIONCheck_" + chrome.runtime.id;
fas.title = "Basic dialog";
fas.innerHTML = "<p>This is the default dialog which is useful for displaying information. The dialog window can be moved, resized and closed with the &apos;x&apos; icon.</p>";
(document.head || document.documentElement).appendChild(fas); 
 